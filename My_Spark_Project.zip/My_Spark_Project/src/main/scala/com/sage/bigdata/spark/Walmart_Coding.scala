package com.sage.bigdata.spark

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.{StringType, StructType}
import org.apache.spark.sql.functions.{col, from_json}

object Walmart_Coding {
  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkSession
      .builder()
      .appName("Pilot_Streaming")
      .getOrCreate()

    import spark.implicits._

    val schema = new StructType()
      .add("Time", StringType, nullable = true)
      .add("UserID", StringType, nullable = true)
      .add("ClickEvent", StringType, nullable = true)


    val df = spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "54.202.102.34:9092")
      .option("spark.sql.adaptive.enabled", value = false)
      .option("subscribe", "bigdata_pilot_flower")
      .option("includeHeaders", "true")
      .load()

    val df_1 = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "headers")
      .as[(String, String, Array[(String, Array[Byte])])]

    val df_2 = df_1.withColumn("jsonData", from_json(col("value"), schema))
      .select("jsonData.*")

    val query = df_2.writeStream
      .option("path", "/user/hadoop/spark_streaming_data/")
      .option("checkpointLocation", "/user/hadoop/streaming")
      .outputMode("append")
      .format("parquet")
      .start()

    query.awaitTermination()


  }

}