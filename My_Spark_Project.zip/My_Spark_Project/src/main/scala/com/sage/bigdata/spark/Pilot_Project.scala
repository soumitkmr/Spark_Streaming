package com.sage.bigdata.spark

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.sql.functions._

object Pilot_Project {

  def main(args: Array[String]): Unit = {

    // Creating Spark Session
    val spark: SparkSession = SparkSession
      .builder()
      .appName("Pilot_Project")
      .enableHiveSupport()
      .getOrCreate()


    // Creating User dataframe from hive user table
    val users_df = spark.sql("SELECT * from practical_exercise.users")
    users_df.show()
    users_df.printSchema()

    val activitylog_df = spark.sql("SELECT * from practical_exercise.activitylog")
    activitylog_df.show()
    activitylog_df.printSchema()

    val user_dump_df = spark.sql("SELECT * from practical_exercise.user_upload_dump")
    user_dump_df.show()
    user_dump_df.printSchema()


 /////////////////////////////////////////////////////// Reporting Table 2 /////////////////////////////////////////////

    val df1 = activitylog_df.select(col("current_timestamp").as("time_ran"), countDistinct(col("user_id")).as("total_users"))
    //df1.show()

    val activitylog1 = activitylog_df.withColumn("Time_Stamp", from_unixtime(floor(col("timestamp")/1000)))
    // activitylog1.show()

    val df2 = activitylog1.filter(col("Time_Stamp").between("1970-01-19 00:00:00", "1970-01-20 00:00:00")).select(countDistinct("user_id").as("user_added"), (col("current_timestamp").as("time_ran")))
    // df2.show()

    val deliverablereport_test = df1.join(df2,df1("time_ran") === df2("time_ran"),"inner" )
    // deliverablereport_test.show()

    val deliverablereport2 = deliverablereport_test.drop(df2("time_ran"))
    deliverablereport2.show()

    //deliverablereport2.write.format("parquet").saveAsTable("practical_exercise.deliverablereport2")
    //deliverablereport2.write.mode("overwrite").parquet("/user/hadoop/deliverablereport2.parquet")

   ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    ////////////////////////////////////////////////////// Reporting Table 1 /////////////////////////////////////////////

    def nvl(ColIn: Column, ReplaceVal: Any): Column = { (when(ColIn.isNull, lit(ReplaceVal)).otherwise(ColIn))}

    var df3 = activitylog_df.filter("type='UPDATE'").groupBy("user_id","type").count().select("user_id","count")
    df3 = df3.withColumnRenamed("user_id", "u3id").withColumnRenamed("count", "update_count")

    var df4 = activitylog_df.filter("type='DELETE'").groupBy("user_id", "type").count().select("user_id","count")
    df4 = df4.withColumnRenamed("user_id", "u4id").withColumnRenamed("count", "delete_count")

    var df5 = activitylog_df.filter("type='INSERT'").groupBy("user_id", "type").count().select("user_id","count")
    df5 = df5.withColumnRenamed("user_id", "u5id").withColumnRenamed("count", "insert_count")

    var df6 = activitylog_df.withColumn("rank", row_number.over(Window.partitionBy("user_id").orderBy(desc("timestamp")))).filter("rank=1").select("user_id", "type")
    df6 = df6.withColumnRenamed("user_id", "u6id").withColumnRenamed("type", "activity_type")

    var df7= activitylog_df.withColumn("differ",datediff(current_timestamp(),from_unixtime(floor(col("timestamp")/1000)))).withColumn("is_active" , when(col("differ") <= 2, "TRUE").otherwise("FALSE")).select("user_id", "is_active")
    df7 = df7.withColumnRenamed("user_id", "u7id").dropDuplicates("u7id")

    var df8 = user_dump_df.groupBy("user_id").count().select("user_id", "count")
    df8 = df8.withColumnRenamed("user_id", "u8id").withColumnRenamed("count","upload_count")


    val dj1 = users_df.join(df3, users_df("id") === df3("u3id"), "left_outer").select("id", "update_count")
    val dj2 = dj1.join(df4, dj1("id") === df4("u4id"), "left_outer").select("id","update_count", "delete_count")
    val dj3 = dj2.join(df5, dj2("id") === df5("u5id"), "left_outer").select("id","update_count","delete_count","insert_count")
    val dj4 = dj3.join(df6, dj3("id") === df6("u6id"), "left_outer").select("id","update_count", "delete_count", "insert_count", "activity_type")
    val dj5 = dj4.join(df7, dj4("id") === df7("u7id"), "left_outer").select("id","update_count", "delete_count", "insert_count", "activity_type", "is_active")
    val dj6 = dj5.join(df8, dj5("id")=== df8("u8id"), "left_outer").select(col("id"), nvl(col("update_count"), 0).as("update_count"), nvl(col("delete_count"), 0).as("delete_count"), nvl(col("insert_count"), 0).as("insert_count"), col("activity_type"), col("is_active"), nvl(col("upload_count"), 0).as("upload_count"))
    dj6.show()

    //dj6.write.format("parquet").saveAsTable("practical_exercise.deliverablereport1")
    // dj6.write.mode("overwrite").parquet("/user/hadoop/deliverablereport1.parquet")

  }
}
