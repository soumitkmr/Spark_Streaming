package com.sage.bigdata.spark

import org.apache.spark.sql.SparkSession

object Streaming {
  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkSession
      .builder()
      .appName("Pilot_Streaming")
      .getOrCreate()

    import spark.implicits._
    val df = spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "54.202.102.34:9092")
      .option("spark.sql.adaptive.enabled", value = false)
      .option("subscribe", "bigdata_pilot_flower")
      .load()



    val df_1 = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
      .as[(String, String)]

    val query = df_1.writeStream
      .outputMode("append")
      .format("console")
      .start()

    query.awaitTermination()






  }




}
